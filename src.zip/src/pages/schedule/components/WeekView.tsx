import { useEffect, useMemo, useRef, useState } from 'react'
import {
    addDays,
    format,
    isSameDay,
    setHours,
    setMinutes,
    startOfDay,
    startOfWeek,
} from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { cn } from '@/lib/utils'
import {
    Appointment,
    Pet,
    Client,
    Profile,
    BusinessHours,
} from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
    ContextMenu,
    ContextMenuContent,
    ContextMenuItem,
    ContextMenuSeparator,
    ContextMenuTrigger,
    ContextMenuSub,
    ContextMenuSubTrigger,
    ContextMenuSubContent,
} from '@/components/ui/context-menu'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog'
import { Pencil, XCircle, Trash2, Plus } from 'lucide-react'

interface WeekViewProps {
    currentDate: Date
    events: Appointment[]
    pets?: Pet[]
    clients?: Client[]
    profiles?: Profile[]
    onEventClick: (event: Appointment) => void
    onCancelAppointment: (event: Appointment) => void
    onDeleteAppointment: (event: Appointment) => void
    onUpdateStatus?: (id: string, status: Appointment['status']) => void
    onTimeClick: (date: Date) => void
    onEventDrop: (event: Appointment, newDate: Date) => void
    mode?: 'day' | 'week' | 'month'
    startHour?: number
    endHour?: number
    businessHours?: BusinessHours
    activeProfiles?: string[]
}

const statusLabels: Record<string, string> = {
    scheduled: 'Agendado',
    confirmed: 'Confirmado',
    in_progress: 'Em Atendimento',
    completed: 'Finalizado',
    cancelled: 'Cancelado',
    checked_in: 'Hospedado',
    checked_out: 'Encerrado',
};

const HOUR_HEIGHT = 44
const MAX_VISIBLE_COLUMNS = 3
const MIN_EVENT_HEIGHT_PERCENT = 4
const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'] as const

type DayBusinessBlock = {
    isOpenAllDay: boolean
    isClosedAllDay: boolean
    firstStart: number | null
    firstEnd: number | null
    secondStart: number | null
    secondEnd: number | null
}

interface EventLayout {
    event: Appointment
    col: number
    numCols: number
    hiddenCount?: number
    isOverflowAnchor?: boolean
}

function getEventStart(evt: Appointment) {
    return new Date(evt.date)
}

function getEventEnd(evt: Appointment) {
    return new Date(new Date(evt.date).getTime() + (evt.duration || 30) * 60_000)
}

function safeTimeToMin(value: unknown): number | null {
    if (value == null) return null

    if (typeof value === 'string') {
        const match = value.match(/^(\d{1,2}):(\d{2})/)
        if (!match) return null

        const h = Number(match[1])
        const m = Number(match[2])

        if (Number.isNaN(h) || Number.isNaN(m)) return null
        return h * 60 + m
    }

    if (typeof value === 'number') {
        return Number.isNaN(value) ? null : value
    }

    return null
}

function getServiceLabel(type: string) {
    switch (type) {
        case 'grooming': return 'Banho e Tosa'
        case 'consultation': return 'Consulta'
        case 'hospitalization': return 'Internação'
        default: return 'Hospedagem'
    }
}

function resolveBusinessBlock(businessHours: any, day: Date): DayBusinessBlock {
    const openAllDay = { isOpenAllDay: true, isClosedAllDay: false, firstStart: null, firstEnd: null, secondStart: null, secondEnd: null }
    if (!businessHours || 'openHour' in businessHours || 'closeHour' in businessHours) return openAllDay

    const dayKey = DAY_KEYS[day.getDay()]
    const config = businessHours?.[dayKey]

    if (!config) {
        return {
            isOpenAllDay: true,
            isClosedAllDay: false,
            firstStart: null,
            firstEnd: null,
            secondStart: null,
            secondEnd: null,
        }
    }

    if (config.open === false) {
        return {
            isOpenAllDay: false,
            isClosedAllDay: true,
            firstStart: null,
            firstEnd: null,
            secondStart: null,
            secondEnd: null,
        }
    }

    const start = safeTimeToMin(config.start)
    const end = safeTimeToMin(config.end)
    const breakStart = safeTimeToMin(config.breakStart)
    const breakEnd = safeTimeToMin(config.breakEnd)
    const end2 = safeTimeToMin(config.end2)

    const hasSecondShift =
        breakStart !== null &&
        breakEnd !== null &&
        end2 !== null &&
        breakEnd > breakStart

    const firstStart = start
    const firstEnd = hasSecondShift ? breakStart : end
    const secondStart = hasSecondShift ? breakEnd : null
    const secondEnd = hasSecondShift ? end2 : null

    if (firstStart === null || firstEnd === null) {
        return {
            isOpenAllDay: true,
            isClosedAllDay: false,
            firstStart: null,
            firstEnd: null,
            secondStart: null,
            secondEnd: null,
        }
    }

    return {
        isOpenAllDay: false,
        isClosedAllDay: false,
        firstStart,
        firstEnd,
        secondStart,
        secondEnd,
    }
}

function isWithinBusinessHours(businessHours: any, day: Date, hour: number) {
    const block = resolveBusinessBlock(businessHours, day)

    if (block.isOpenAllDay) return true
    if (block.isClosedAllDay) return false

    const slotStart = hour * 60
    const slotEnd = slotStart + 60

    const overlapsFirst =
        block.firstStart !== null &&
        block.firstEnd !== null &&
        slotStart < block.firstEnd &&
        slotEnd > block.firstStart

    const overlapsSecond =
        block.secondStart !== null &&
        block.secondEnd !== null &&
        slotStart < block.secondEnd &&
        slotEnd > block.secondStart

    return overlapsFirst || overlapsSecond
}

function layoutOverlappingEvents(events: Appointment[]): EventLayout[] {
    if (events.length === 0) return []

    const sorted = [...events].sort(
        (a, b) => getEventStart(a).getTime() - getEventStart(b).getTime(),
    )

    const overlaps = (a: Appointment, b: Appointment) =>
        getEventStart(a).getTime() < getEventEnd(b).getTime() &&
        getEventStart(b).getTime() < getEventEnd(a).getTime()

    const clusters: Appointment[][] = []

    for (const evt of sorted) {
        const target = clusters.find((cluster) =>
            cluster.some((item) => overlaps(item, evt)),
        )

        if (target) {
            target.push(evt)
        } else {
            clusters.push([evt])
        }
    }

    const layouts: EventLayout[] = []

    for (const cluster of clusters) {
        const colEnds: number[] = []
        const assignments: { event: Appointment; col: number }[] = []

        for (const evt of cluster) {
            const start = getEventStart(evt).getTime()
            const end = getEventEnd(evt).getTime()

            let col = colEnds.length

            for (let i = 0; i < colEnds.length; i++) {
                if (colEnds[i] <= start) {
                    col = i
                    break
                }
            }

            if (col < colEnds.length) {
                colEnds[col] = end
            } else {
                colEnds.push(end)
            }

            assignments.push({ event: evt, col })
        }

        const actualCols = colEnds.length

        if (actualCols <= MAX_VISIBLE_COLUMNS) {
            for (const { event, col } of assignments) {
                layouts.push({ event, col, numCols: actualCols })
            }
            continue
        }

        const visibleAssignments = assignments.filter(
            (item) => item.col < MAX_VISIBLE_COLUMNS,
        )
        const overflowAssignments = assignments.filter(
            (item) => item.col >= MAX_VISIBLE_COLUMNS,
        )

        for (const { event, col } of visibleAssignments) {
            const isLastVisibleCol = col === MAX_VISIBLE_COLUMNS - 1
            const hiddenCount = isLastVisibleCol ? overflowAssignments.length : 0

            layouts.push({
                event,
                col,
                numCols: MAX_VISIBLE_COLUMNS,
                hiddenCount,
                isOverflowAnchor: isLastVisibleCol && overflowAssignments.length > 0,
            })
        }
    }

    return layouts
}

export function WeekView({
    currentDate,
    events,
    pets = [],
    clients = [],
    profiles = [],
    onEventClick,
    onCancelAppointment,
    onDeleteAppointment,
    onUpdateStatus,
    onTimeClick,
    onEventDrop,
    mode = 'week',
    startHour = 7,
    endHour = 19,
    businessHours,
    activeProfiles = [],
}: WeekViewProps) {
    const [confirmCancel, setConfirmCancel] = useState<Appointment | null>(null)
    const [confirmDelete, setConfirmDelete] = useState<Appointment | null>(null)
    const [dragOverCell, setDragOverCell] = useState<string | null>(null)
    const [currentTime, setCurrentTime] = useState(new Date())
    const scrollRef = useRef<HTMLDivElement>(null)

    useEffect(() => {
        const id = setInterval(() => setCurrentTime(new Date()), 60_000)
        return () => clearInterval(id)
    }, [])

    useEffect(() => {
        const container = scrollRef.current
        if (!container) return

        const now = new Date()
        const currentMinutes = now.getHours() * 60 + now.getMinutes()
        const startMinutes = startHour * 60
        const endMinutes = endHour * 60

        if (currentMinutes < startMinutes || currentMinutes > endMinutes) {
            container.scrollTop = 0
            return
        }

        const totalMinutes = (endHour - startHour) * 60
        const targetMinutes = Math.max(startMinutes, currentMinutes - 90)
        const scrollRatio = (targetMinutes - startMinutes) / totalMinutes

        container.scrollTop = Math.max(0, scrollRatio * (container.scrollHeight * 0.75))
    }, [startHour, endHour, currentDate])

    const weekStart = useMemo(
        () => startOfWeek(currentDate, { weekStartsOn: 0 }),
        [currentDate],
    )

    const weekDays = useMemo(() => {
        return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))
    }, [weekStart])

    const hourSlots = useMemo(() => {
        const slots: number[] = []
        for (let h = startHour; h < endHour; h++) {
            slots.push(h)
        }
        return slots
    }, [startHour, endHour])

    const filteredEvents = useMemo(() => {
        return events
            .filter((evt) => evt.serviceType !== 'boarding')
            .filter((evt) => {
                if (activeProfiles.length === 0) return true

                const profId = evt.professionalId || 'unassigned'
                return activeProfiles.includes(profId)
            })
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    }, [events, activeProfiles])

    const currentLine = useMemo(() => {
        const todayIndex = weekDays.findIndex((day) => isSameDay(day, currentTime))
        if (todayIndex === -1) return null

        const currentMinutes = currentTime.getHours() * 60 + currentTime.getMinutes()
        const startMinutes = startHour * 60
        const endMinutes = endHour * 60

        if (currentMinutes < startMinutes || currentMinutes > endMinutes) {
            return null
        }

        const top =
            ((currentMinutes - startMinutes) / ((endHour - startHour) * 60)) * 100

        return { dayIndex: todayIndex, top }
    }, [weekDays, currentTime, startHour, endHour])

    const totalGridHeight = (endHour - startHour) * HOUR_HEIGHT

    const eventsByDay = useMemo(() => {
        const map = new Map<string, Appointment[]>()

        for (const day of weekDays) {
            const key = format(day, 'yyyy-MM-dd')
            map.set(key, [])
        }

        for (const evt of filteredEvents) {
            const evtDate = new Date(evt.date)
            const key = format(evtDate, 'yyyy-MM-dd')

            if (!map.has(key)) continue
            map.get(key)!.push(evt)
        }

        for (const [key, list] of map.entries()) {
            list.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            map.set(key, list)
        }

        return map
    }, [filteredEvents, weekDays])

    const dayLayouts = useMemo(() => {
        const map = new Map<string, EventLayout[]>()

        for (const day of weekDays) {
            const key = format(day, 'yyyy-MM-dd')
            const dayEvents = eventsByDay.get(key) || []
            map.set(key, layoutOverlappingEvents(dayEvents))
        }

        return map
    }, [weekDays, eventsByDay])

    const renderEventCard = (
        evt: Appointment,
        style: React.CSSProperties,
        overflowHint?: number,
    ) => {
        const pet = pets.find((p) => String(p.id) === String(evt.petId))
        const professional = profiles.find((p) => String(p.id) === String(evt.professionalId))
        const client = pet ? clients.find((c) => String(c.id) === String((pet as any).clientId)) : undefined
        const serviceLabel = getServiceLabel(evt.serviceType)
        const timeLabel = format(new Date(evt.date), 'HH:mm')
        const hasOverflow = typeof overflowHint === 'number' && overflowHint > 0

        const substatus = evt.clinicalStatus || evt.groomingStatus;

        return (
            <ContextMenu key={evt.id}>
                <ContextMenuTrigger asChild>
                    <div
                        className={cn(
                            'absolute rounded-lg border shadow-sm cursor-pointer overflow-hidden transition-all hover:shadow-md z-20 hover:z-30',
                            evt.status === 'scheduled' && 'bg-slate-100 border-slate-400 text-slate-700',
                            evt.status === 'confirmed' && 'bg-blue-100 border-blue-500 text-blue-800',
                            evt.status === 'in_progress' && 'bg-amber-100 border-amber-400 text-amber-800',
                            evt.status === 'completed' && 'bg-green-100 border-green-500 text-green-800',
                            evt.status === 'cancelled' && 'bg-red-100 border-red-500 text-red-800',
                            evt.serviceType === 'hospitalization' && 'border-l-red-500 border-l-4',
                        )}
                        style={style}
                        onClick={() => onEventClick(evt)}
                        draggable
                        onDragStart={(e) => e.dataTransfer.setData('text/plain', evt.id)}
                        title={[
                            `${timeLabel} - ${serviceLabel}`,
                            pet ? `Pet: ${pet.name}` : '',
                            client ? `Tutor: ${client.name}` : '',
                            professional ? `${professional.name}` : 'Sem responsável',
                            `${statusLabels[evt.status] || evt.status}`,
                        ]
                            .filter(Boolean)
                            .join('\n')}
                    >
                        <div className="h-full flex flex-col justify-center px-2 py-0.5 relative">
                            <div className="flex items-center gap-1.5 truncate leading-none">
                                <span className="text-[10px] font-bold text-slate-700 shrink-0">{timeLabel}</span>
                                <span className="text-[11px] font-bold text-slate-900 truncate">{pet?.name || 'Pet'}</span>
                                {evt.serviceType === 'hospitalization' && (
                                    <span className="text-red-600 text-[8px] font-extrabold shrink-0">INT</span>
                                )}
                            </div>



                            {hasOverflow ? (
                                <div className="mt-1 text-[8px] font-medium opacity-80 bg-white/40 rounded px-1 w-fit">
                                    +{overflowHint}
                                </div>
                            ) : null}
                        </div>
                    </div>
                </ContextMenuTrigger>

                <ContextMenuContent>
                    <ContextMenuItem onClick={() => onEventClick(evt)}>
                        <Pencil className="mr-2 h-4 w-4" />
                        Editar
                    </ContextMenuItem>

                    <ContextMenuSeparator />

                    {evt.status === 'scheduled' && (
                        <ContextMenuItem onClick={() => onUpdateStatus?.(evt.id, 'confirmed')}>
                            <Badge className="mr-2 h-2 w-2 rounded-full bg-blue-500 p-0" />
                            Confirmar Atendimento
                        </ContextMenuItem>
                    )}

                    {evt.status !== 'cancelled' && evt.status !== 'completed' && (
                        <ContextMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => setConfirmCancel(evt)}
                        >
                            <XCircle className="mr-2 h-4 w-4" />
                            Cancelar Agendamento
                        </ContextMenuItem>
                    )}

                    {evt.status === 'cancelled' && (
                        <ContextMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => setConfirmDelete(evt)}
                        >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Excluir Agendamento
                        </ContextMenuItem>
                    )}
                </ContextMenuContent>
            </ContextMenu>
        )
    }

    return (
        <div className="flex flex-col h-full border rounded-2xl bg-background overflow-hidden shadow-sm">
            <div className="grid grid-cols-[64px_repeat(7,1fr)] border-b bg-muted/30">
                <div className="border-r" />

                {weekDays.map((day) => (
                    <div
                        key={day.toString()}
                        className="border-r last:border-r-0 px-2 py-2 text-center"
                    >
                        <div className="text-xs font-semibold capitalize">
                            {format(day, 'EEE', { locale: ptBR })}
                        </div>

                        <div
                            className={cn(
                                'mt-1 inline-flex h-7 min-w-7 items-center justify-center rounded-full px-2 text-xs font-medium',
                                isSameDay(day, new Date())
                                    ? 'bg-orange-500 text-white'
                                    : 'text-muted-foreground',
                            )}
                        >
                            {format(day, 'dd')}
                        </div>
                    </div>
                ))}
            </div>

            <div ref={scrollRef} className="flex-1 overflow-auto relative">
                <div
                    className="grid grid-cols-[64px_repeat(7,1fr)] relative"
                    style={{ minHeight: `${totalGridHeight}px` }}
                >
                    <div className="border-r bg-background sticky left-0 z-10">
                        {hourSlots.map((hour) => (
                            <div
                                key={`hour-${hour}`}
                                className="border-b px-2 pt-1 text-right text-xs text-muted-foreground"
                                style={{ height: `${HOUR_HEIGHT}px` }}
                            >
                                {String(hour).padStart(2, '0')}:00
                            </div>
                        ))}
                    </div>

                    {weekDays.map((day, dayIndex) => {
                        const dayKey = format(day, 'yyyy-MM-dd')
                        const dayEvents = eventsByDay.get(dayKey) || []
                        const layouts = dayLayouts.get(dayKey) || []
                        const disabledBlocks = (() => {
                            const results = hourSlots.map((hour) => ({
                                hour,
                                enabled: isWithinBusinessHours(businessHours, day, hour),
                                showOutsideLabel: false,
                            }))
                            for (let i = 0; i < results.length; i++) {
                                if (!results[i].enabled) {
                                    const prevEnabled = i === 0 ? true : results[i - 1].enabled
                                    results[i].showOutsideLabel = prevEnabled
                                }
                            }
                            return results
                        })()

                        return (
                            <div
                                key={dayKey}
                                className="relative border-r last:border-r-0 overflow-hidden"
                            >
                                {disabledBlocks.map(({ hour, enabled, showOutsideLabel }) => {
                                    const cellKey = `${dayKey}-${hour}`
                                    const isDragOver = dragOverCell === cellKey

                                    return (
                                        <Button
                                            key={cellKey}
                                            type="button"
                                            variant="ghost"
                                            className={cn(
                                                'w-full justify-start rounded-none border-b px-0 h-auto relative',
                                                enabled
                                                    ? 'hover:bg-muted/20 bg-background'
                                                    : 'bg-slate-100/80 bg-[linear-gradient(135deg,rgba(148,163,184,0.08)_25%,transparent_25%,transparent_50%,rgba(148,163,184,0.08)_50%,rgba(148,163,184,0.08)_75%,transparent_75%,transparent)] bg-[length:12px_12px]',
                                                isDragOver && 'bg-orange-50 ring-1 ring-orange-300',
                                            )}
                                            style={{ height: `${HOUR_HEIGHT}px` }}
                                            onClick={() => {
                                                if (!enabled) return
                                                const clickDate = setMinutes(setHours(startOfDay(day), hour), 0)
                                                onTimeClick(clickDate)
                                            }}
                                            onDragOver={(e) => {
                                                e.preventDefault()
                                                if (!enabled) return
                                                setDragOverCell(cellKey)
                                            }}
                                            onDragLeave={() => {
                                                if (dragOverCell === cellKey) setDragOverCell(null)
                                            }}
                                            onDrop={(e) => {
                                                e.preventDefault()
                                                setDragOverCell(null)

                                                if (!enabled) return

                                                const eventId = e.dataTransfer.getData('text/plain')
                                                const evt =
                                                    dayEvents.find((item) => item.id === eventId) ||
                                                    filteredEvents.find((item) => item.id === eventId)

                                                if (!evt) return

                                                const originalDate = new Date(evt.date)
                                                const newDate = new Date(day)
                                                newDate.setHours(hour, originalDate.getMinutes(), 0, 0)

                                                onEventDrop(evt, newDate)
                                            }}
                                        >
                                            {!enabled && showOutsideLabel && (
                                                <span className="absolute left-2 top-1.5 text-[9px] font-medium text-slate-500 pointer-events-none bg-white/70 px-1 rounded-sm">
                                                    Fora de expediente
                                                </span>
                                            )}
                                        </Button>
                                    )
                                })}

                                {currentLine && currentLine.dayIndex === dayIndex && (
                                    <div
                                        className="absolute left-0 right-0 h-0.5 bg-red-500 z-20 pointer-events-none"
                                        style={{ top: `${currentLine.top}%` }}
                                    />
                                )}

                                {layouts.map(({ event: evt, col, numCols, hiddenCount, isOverflowAnchor }) => {
                                    const eventStart = getEventStart(evt)
                                    const eventEnd = getEventEnd(evt)

                                    const gridStartMinutes = startHour * 60
                                    const gridEndMinutes = endHour * 60

                                    const rawStartMinutes =
                                        eventStart.getHours() * 60 + eventStart.getMinutes()
                                    const rawEndMinutes =
                                        eventEnd.getHours() * 60 + eventEnd.getMinutes()

                                    if (
                                        rawEndMinutes <= gridStartMinutes ||
                                        rawStartMinutes >= gridEndMinutes
                                    ) {
                                        return null
                                    }

                                    const visibleStartMinutes = Math.max(rawStartMinutes, gridStartMinutes)
                                    const visibleEndMinutes = Math.min(rawEndMinutes, gridEndMinutes)

                                    const startMinutes = visibleStartMinutes - gridStartMinutes
                                    const endMinutes = visibleEndMinutes - gridStartMinutes

                                    const top =
                                        (startMinutes / ((endHour - startHour) * 60)) * 100
                                    const height =
                                        ((endMinutes - startMinutes) / ((endHour - startHour) * 60)) * 100

                                    const width = 100 / numCols
                                    const left = col * width

                                    return renderEventCard(
                                        evt,
                                        {
                                            top: `${top}%`,
                                            height: `${Math.max(height, MIN_EVENT_HEIGHT_PERCENT)}%`,
                                            left: `calc(${left}% + 3px)`,
                                            width: `calc(${width}% - 6px)`,
                                        },
                                        isOverflowAnchor ? hiddenCount : undefined,
                                    )
                                })}
                            </div>
                        )
                    })}
                </div>
            </div>

            <Dialog open={!!confirmCancel} onOpenChange={() => setConfirmCancel(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Cancelar Agendamento</DialogTitle>
                        <DialogDescription>
                            Tem certeza que deseja cancelar este agendamento?
                        </DialogDescription>
                    </DialogHeader>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setConfirmCancel(null)}>
                            Voltar
                        </Button>

                        <Button
                            variant="destructive"
                            onClick={() => {
                                if (confirmCancel) onCancelAppointment(confirmCancel)
                                setConfirmCancel(null)
                            }}
                        >
                            Confirmar Cancelamento
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={!!confirmDelete} onOpenChange={() => setConfirmDelete(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Excluir Agendamento</DialogTitle>
                        <DialogDescription>
                            Tem certeza que deseja excluir o agendamento? Esta ação não pode ser desfeita.
                        </DialogDescription>
                    </DialogHeader>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => setConfirmDelete(null)}>
                            Voltar
                        </Button>

                        <Button
                            variant="destructive"
                            onClick={() => {
                                if (confirmDelete) onDeleteAppointment(confirmDelete)
                                setConfirmDelete(null)
                            }}
                        >
                            Sim, Excluir
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}