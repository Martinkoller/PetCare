import api from '@/lib/api'
import {
  HospitalizationStay,
  HospitalizationStatus,
  AdmitPetPayload,
  AddLogPayload,
  DischargePayload,
} from '@/lib/types'


export const hospitalizationService = {
  async getStays(): Promise<HospitalizationStay[]> {
    const response = await api.get<HospitalizationStay[]>('/hospitalization/stays')
    return response.data
  },

  async admitPet(payload: AdmitPetPayload & { pet?: HospitalizationStay['pet'] }): Promise<HospitalizationStay> {
    if (!payload.kennelNumber?.trim()) {
      throw new Error('O leito é obrigatório para iniciar a internação.')
    }

    const response = await api.post<HospitalizationStay>('/hospitalization/stays', payload)
    return response.data
  },

  async addLog(stayId: string, payload: AddLogPayload): Promise<HospitalizationStay> {
    const response = await api.post<HospitalizationStay>(`/hospitalization/stays/${stayId}/logs`, payload)
    return response.data
  },

  async dischargeStay(stayId: string, payload: DischargePayload): Promise<HospitalizationStay> {
    const response = await api.patch<HospitalizationStay>(`/hospitalization/stays/${stayId}/discharge`, payload)
    return response.data
  },

  async updateStayStatus(stayId: string, status: HospitalizationStatus): Promise<HospitalizationStay> {
    const response = await api.patch<HospitalizationStay>(`/hospitalization/stays/${stayId}/status`, { status })
    return response.data
  },
}
